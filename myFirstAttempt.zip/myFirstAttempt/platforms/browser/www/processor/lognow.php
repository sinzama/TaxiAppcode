<?php
	// configuration
	include('../connect.php');

	$fname    = $_POST['fname'];
	$lname    = $_POST['lname'];
	$email    = $_POST['email'];

	// Check if the user has not booked before
	$count = $db->fetch('users', array('email' => $email), 'count');  

	// There is no existing email of the same
	// kind as the one given then....
	if($count == 0){
		$result = $db->insert('users', array('fname' => $fname,
											 'lname' => $lname,
											 'email' => $email));
	}

	echo $result;
	exit();
?>