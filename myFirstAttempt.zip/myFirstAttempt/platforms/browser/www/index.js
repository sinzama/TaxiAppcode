function Register(){
          $('#lognow').click(function()
        {  
            var url ='processor/lognow.php';
            var onclick = '#lognow';
            alert('hi');

            $.post(url,onclick, function(response){
                console.log(response); 
            });
        });
    }